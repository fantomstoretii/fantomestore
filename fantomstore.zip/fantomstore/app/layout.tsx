import type { Metadata } from "next";
import { Fraunces, Manrope } from "next/font/google";
import "./globals.css";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  display: "swap",
});

const manrope = Manrope({
  subsets: ["latin"],
  variable: "--font-manrope",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Fantômes — Débusque les abonnements qu'on paie sans s'en servir",
  description:
    "Dépose ton relevé bancaire, Fantômes repère les abonnements oubliés et génère les lettres de résiliation. Économise en quelques minutes.",
  openGraph: {
    title: "Fantômes — Débusque les abonnements qu'on paie sans s'en servir",
    description:
      "Dépose ton relevé bancaire, Fantômes repère les abonnements oubliés et génère les lettres de résiliation.",
    type: "website",
    locale: "fr_FR",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr">
      <body className={`${fraunces.variable} ${manrope.variable} font-sans bg-creme text-nuit`}>
        {children}
      </body>
    </html>
  );
}
