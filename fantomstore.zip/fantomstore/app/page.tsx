export default function Home() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-6 py-16 text-center">
      <span className="inline-block rounded-full border border-dore/40 px-4 py-1 text-sm text-dore mb-6">
        Bientôt disponible
      </span>

      <h1 className="font-serif text-4xl sm:text-5xl leading-tight max-w-xl">
        Débusque les abonnements qu&apos;on paie sans s&apos;en servir
      </h1>

      <p className="mt-5 text-lg text-nuit/70 max-w-md">
        Dépose ton relevé bancaire. Fantômes repère chaque prélèvement oublié
        et prépare la lettre de résiliation.
      </p>

      <div className="mt-10 w-full max-w-xs">
        <div className="w-full rounded-xl bg-nuit text-creme font-semibold py-4 px-6 opacity-60 cursor-not-allowed">
          Paiement bientôt activé
        </div>
        <p className="mt-3 text-sm text-nuit/50">
          Le site est en construction — reviens très vite.
        </p>
      </div>

      <footer className="mt-20 text-xs text-nuit/40">
        Fantômes — © {new Date().getFullYear()}
      </footer>
    </main>
  );
}
